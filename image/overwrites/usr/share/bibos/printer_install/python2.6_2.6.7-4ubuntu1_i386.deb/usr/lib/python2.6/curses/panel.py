"""curses.panel

Module for using panels with curses.
"""

__revision__ = "$Id: panel.py 36560 2004-07-18 06:16:08Z tim_one $"

from _curses_panel import *
